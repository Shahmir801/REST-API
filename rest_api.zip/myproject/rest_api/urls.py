from django.urls import path
from . import views
urlpatterns=[
    path('persons',views.people_list,name="get_data"),
    path('person_data/<int:pk>',views.person_detail,name="get_person_data"),
]