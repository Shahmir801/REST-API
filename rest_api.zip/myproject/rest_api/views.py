from django.shortcuts import render, get_object_or_404
from .models import Data
from django.http import HttpResponse, JsonResponse
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from .serializer import Datasearializer
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
# Create your views here.
@api_view(['GET', 'POST'])
def people_list(request):
    if request.method=="GET":
        data = Data.objects.all()
        datasearializer = Datasearializer(data, many=True)
        return Response(datasearializer.data)
    elif request.method=="POST":
        datasearializer = Datasearializer(data=request.data)
        if datasearializer.is_valid():
            datasearializer.save()
            return Response(datasearializer.data, status=status.HTTP_201_CREATED)
        else:
            return JsonResponse(datasearializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET', 'PUT', 'DELETE'])
def person_detail(request, pk):
    data = None
    try:
        data = Data.objects.get(pk=pk)
    except Data.DoesNotExist:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)
    if request.method=="GET":
        datasearializer = Datasearializer(data)
        return Response(datasearializer.data)
    elif request.method=="PUT":
        datasearializer = Datasearializer(data=request.data)
        if datasearializer.is_valid():
            datasearializer.save()
            return Response(datasearializer.data)
        else:
            return Response(datasearializer.errors, status=status.HTTP_400_BAD_REQUEST)
    elif request.method=='DELETE':
        data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)